from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from db.database import init_db
from routers import auth, complaints, locker, certificates, notifications, dashboard, admin_users
import os

# Initialize FastAPI app
app = FastAPI(
    title="OneServe API",
    description="Unified Digital Platform for Government & Professional Services",
    version="1.0.0"
)

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://localhost:3000"],  # React dev server
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize database
@app.on_event("startup")
def on_startup():
    init_db()
    print("✅ Database initialized")

# Include routers
app.include_router(auth.router)
app.include_router(complaints.router)
app.include_router(locker.router)
app.include_router(certificates.router)
app.include_router(notifications.router)
app.include_router(dashboard.router)
app.include_router(admin_users.router)

# Mount uploads folder for static files
os.makedirs("uploads", exist_ok=True)
os.makedirs("uploads/complaints", exist_ok=True)
os.makedirs("uploads/locker", exist_ok=True)
os.makedirs("uploads/certificates", exist_ok=True)

# Serve complaint images
from fastapi.responses import FileResponse
from fastapi import HTTPException

@app.get("/files/complaints/{filename}")
async def get_complaint_image(filename: str):
    """Serve complaint images"""
    file_path = os.path.join("uploads/complaints", filename)
    if os.path.exists(file_path):
        return FileResponse(file_path)
    raise HTTPException(status_code=404, detail="File not found")

@app.get("/files/locker/{filename}")
async def get_locker_document(filename: str):
    """Serve locker documents"""
    file_path = os.path.join("uploads/locker", filename)
    if os.path.exists(file_path):
        return FileResponse(file_path)
    raise HTTPException(status_code=404, detail="File not found")

@app.get("/files/certificates/{filename}")
async def get_certificate_file(filename: str):
    """Serve certificate files"""
    file_path = os.path.join("uploads/certificates", filename)
    if os.path.exists(file_path):
        return FileResponse(file_path)
    raise HTTPException(status_code=404, detail="File not found")

# Root endpoint
@app.get("/")
def root():
    return {
        "message": "OneServe API",
        "version": "1.0.0",
        "docs": "/docs"
    }

# Health check
@app.get("/health")
def health_check():
    return {"status": "healthy"}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
